
extern int ASM_funct(int*, int);

int main(void){

	int n = 5;
	int v[] = {1, 2, 3, 4, 5};
	volatile int r=0;

	r = ASM_funct(v, n);
		
	while(1);
}
